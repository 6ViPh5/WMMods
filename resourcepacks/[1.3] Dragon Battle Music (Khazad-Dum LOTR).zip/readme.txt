				|IMPORTANT!|
Don't forget to turn on the settings you need to activate in Euphoria Patches! ↓↓↓
End Crystal Vortex: "BOTH" | Dragon Death Effect: "ON"

====
Can You Hear The Music by Ludwig Goransson = https://www.youtube.com/watch?v=4JZ-o3iAJv4

Khazad-dum and The Bridge of Khazad by Howard Shore = https://www.youtube.com/watch?v=f44xDz2tW_I & https://www.youtube.com/watch?v=vbKy6FuACKg

Aria Math Remix by Stache Mo = https://www.youtube.com/watch?v=Torii4FEge4
====

> If the owners of the musics want their music not to be used, they can contact me on Twitter.
Here is the Link = https://x.com/bbayyt