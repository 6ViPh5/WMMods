**This pack was created by GabrielDja**  

**LINKS**  
Website : https://gabrieldjalayer.wixsite.com/gabrieldja-gaming-yt  
CurseForge : https://www.curseforge.com/members/gabriel_dja/projects  
Modrinth : https://modrinth.com/user/GabrielDja

---------

See my project licenses : https://gabriel-djalayer.gitbook.io/gdteam-wiki/guides/licenses